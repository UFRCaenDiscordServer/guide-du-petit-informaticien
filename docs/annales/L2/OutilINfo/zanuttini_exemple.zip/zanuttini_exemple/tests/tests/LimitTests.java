package tests;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import algorithms.IntegerSorter;
import algorithms.MergeSorter;
import algorithms.SelectionSorter;

/**
 * An executable class for running limit tests on sorting algorithms of
 * package {@link algorithms}. If a test fails, a message is printed to
 * standard error and the program exits with code 1.
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public class LimitTests {

    /**
     * Runs the class.
     * @param args ignored
     */
    public static void main (String [] args) {
        LimitTests.test(Collections.emptySet());
        LimitTests.test(Collections.singleton(0));
        LimitTests.test(Collections.singleton(-1));
        LimitTests.test(Collections.singleton(Integer.MAX_VALUE));
        LimitTests.test(Arrays.asList(0, 0));
        LimitTests.test(Arrays.asList(0, 1));
        LimitTests.test(Arrays.asList(Integer.MIN_VALUE, 0));
        LimitTests.test(Arrays.asList(0, Integer.MAX_VALUE));
        LimitTests.test(Arrays.asList(Integer.MIN_VALUE, Integer.MAX_VALUE));
        System.out.println("All tests passed");
    }
    
    /**
     * Tests each algorithm on a given collection of objects.
     * @param objects A collection of objects
     */
    public static void test (Collection<Integer> objects) {
        LimitTests.test(new SelectionSorter(objects), "selection");
        LimitTests.test(new MergeSorter(objects, 2), "merge-2");
        LimitTests.test(new MergeSorter(objects, 10), "merge-10");
    }

    /**
     * Tests a given sorter.
     * @param sorter A sorter
     * @param name The name of the sorter, as should be printed out
     */
    public static void test (IntegerSorter sorter, String name) {
        System.out.println("Testing with collection " + sorter.getObjects() + " and " + name + " sorter");
        boolean res = new Tester(sorter).test();
        if ( ! res ) {
            System.err.println("Test failed");
            System.exit(1);
        }
    }
    
}

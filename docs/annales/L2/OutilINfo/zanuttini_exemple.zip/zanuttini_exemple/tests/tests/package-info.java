/**
 * A package providing tests for sorting algorithms of package
 * {@link algorithms}.
 */
package tests;

#!/bin/sh

cd $(dirname $0)/..
[ -d lib ] || mkdir lib
[ -f lib/listgenerators.jar ] && exit 0
cd lib/
wget https://alec.users.greyc.fr/listgenerator/listgenerators.jar

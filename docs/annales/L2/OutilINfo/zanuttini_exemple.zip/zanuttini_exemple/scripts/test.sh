#!/bin/sh

cd $(dirname $0)/..

sh scripts/compile.sh

echo "** Limit tests... **"
java -cp "build:lib/*" tests.LimitTests

echo ""

echo "** Nominal tests... **"
java -cp "build:lib/*" tests.Main selection 100
java -cp "build:lib/*" tests.Main merge-2 1000
java -cp "build:lib/*" tests.Main merge-10 10000


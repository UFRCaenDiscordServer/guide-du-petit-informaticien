#!/bin/sh

cd $(dirname $0)/..
sh scripts/install.sh
[ -d doc ] || mkdir doc
javadoc -d doc -cp "lib/*:src:tests" algorithms benchmarks tests

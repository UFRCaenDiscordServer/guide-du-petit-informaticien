Exemple de cours pour l'unité d'expression-communication en L2 informatique, Université de Caen Normandie.
Préparé par Bruno Zanuttini.

Librairie fournissant des algorithmes de tri (sélection, fusion) dédiés à des collections d'entiers,
ainsi qu'une classe permettant de mesurer leur temps de calcul sur des listes aléatoires d'entiers.

Les sources java de la librairie sont toutes dans le répertoire src/, et les sources des tests
dans le répertoire tests/.

Les commandes principales sont :

- "sh scripts/run.sh [nbElements]" pour lancer le programme avec un nombre d'éléments donné
- "sh scripts/test.sh" pour lancer les tests du programme
- "sh scripts/makejar.sh" pour créer un jar contenant tous les .class
- "sh scripts/makedoc.sh" pour générer la javadoc (le fichier principal est alors doc/index.html)
- "sh scripts/clean.sh" pour supprimer tous les fichiers générés (sauf les librairies)

Ces commandes provoqueront l'installation des librairies externes (ce qui nécessite une connexion
internet) ainsi que la compilation.

La seule librairie externe utilisée est la librairie listgenerators, documentée à l'URL
https://alec.users.greyc.fr/listgenerator/doc/index.html.


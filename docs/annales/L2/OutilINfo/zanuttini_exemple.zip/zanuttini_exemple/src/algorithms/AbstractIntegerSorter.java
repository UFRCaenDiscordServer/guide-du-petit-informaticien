package algorithms;

import java.util.Collection;
import java.util.List;

/**
 * An abstract class for factoring out handling of attributes
 * in implementations of interface {@link IntegerSorter}.
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public abstract class AbstractIntegerSorter implements IntegerSorter {

    /** The collection of integers to sort. */
    protected Collection<Integer> objects;

    /** A variable for storing the result. */
    protected List<Integer> sortedObjects;

    /**
     * Builds a new instance.
     * @param objects The collection of integers to sort
     */
    public AbstractIntegerSorter(Collection<Integer> objects) {
        this.objects = objects;
        this.sortedObjects = null;
    }

    @Override
    public Collection<Integer> getObjects() {
        return this.objects;
    }
    
    @Override
    public List<Integer> getSortedList() throws IllegalStateException {
        if (this.sortedObjects == null) {
            throw new IllegalStateException("Method sort() must be called first");
        }
        return this.sortedObjects;
    }

}

package algorithms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * A class implementing merge sort for collections of integers.
 * The class can be used with any number of subcollections to
 * split the collection into (recursively).
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public class MergeSorter extends AbstractIntegerSorter {

    /** The number of collections to split the collection into. */
    protected int nbSubcollections;

    /**
     * Builds a new instance.
     * @param objects The collection of objects to sort
     * @param nbSubcollections The number of subcollections the
     * algorithm should split the collection into
     */
    public MergeSorter(Collection<Integer> objects, int nbSubcollections) {
        super(objects);
        this.nbSubcollections = nbSubcollections;
    }

    @Override
    public void sort() {
        if (super.sortedObjects != null) {
            // Result has already been computed
            return;
        } else {
            // Perform computation
            super.sortedObjects = this.recursiveSort(objects);
        }
    }

    /**
     * Sorts a given collection of integers, using merge sort (recursively)
     * with the number of subcollections of this instance.
     * @param objects The collection of objects to sort 
     * @return A sorted list containing the same (multiset of) objects
     * as the given collection
     */
    protected List<Integer> recursiveSort(Collection<Integer> objects) {
        if (objects.size() <= 1) {
            // Collection has 0 or 1 element, hence is sorted
            return new ArrayList<>(objects);
        } else {
            // Split and merge
            Collection<Collection<Integer>> subcollections = this.split(objects);
            Collection<List<Integer>> sortedSublists = new ArrayList<>();
            for (Collection<Integer> subcollection: subcollections) {
                sortedSublists.add(this.recursiveSort(subcollection));
            }
            List<Integer> res = MergeSorter.merge(sortedSublists);
            return res;
        }
    }

    /**
     * Splits a given collection of integers into as many subcollections as
     * specified in this instance. The subcollections all have the same size
     * except possibly for the last one, which may be smaller (or nonexistent;
     * e.g., 9 to be split into 4 collections will yield 3 collections of 3 elements.
     * @param objects The collection of objects to split
     * @return A collection of collections of integers
     */
    protected Collection<Collection<Integer>> split(Collection<Integer> objects) {
        Collection<Collection<Integer>> res = new ArrayList<> ();
        int subcollectionSize = (int)Math.ceil((float)objects.size() / this.nbSubcollections);
        Collection<Integer> subcollection = null;
        for (Integer element: objects) {
            if (subcollection == null || subcollection.size() >= subcollectionSize) {
                // Start new subcollection
                subcollection = new ArrayList<>(); 
                res.add(subcollection);
            }
            subcollection.add(element);
        }
        return res;
    }

    /**
     * Merges sorted lists of integers into only one sorted list.
     * For efficiency reasons, it is not checked whether the given lists
     * are indeed sorted.
     * @param sublists A collection of lists of integers, assumed to be sorted
     * @return A sorted list of integers, which contains the same multiset
     * of elements as the disjoint union of the given sublists
     */
    private static List<Integer> merge(Collection<List<Integer>> sublists) {
        List<Integer> res = new ArrayList<>();
        Integer element = MergeSorter.findAndRemoveMinimum(sublists);
        while (element != null) {
            res.add(element);
            element = MergeSorter.findAndRemoveMinimum(sublists);
        }
        return res;
    }

    /**
     * Finds the minimal integer among the first elements of each of given lists,
     * and removes (one occurrence of) it.
     * @param sublists A collection of lists of integers
     * @return The removed element, or null if all lists are empty
     */
    private static Integer findAndRemoveMinimum(Collection<List<Integer>> sublists) {
        // Minimal element found so far
        Integer res = null;
        // List containing minimal element found so far (ignored if res is null)
        List<Integer> list = null;
        // Search
        for (List<Integer> sublist: sublists) {
            if ( ! sublist.isEmpty() ) {
                if (res == null || sublist.get(0) < res) {
                    res = sublist.get(0);
                    list = sublist; 
                }
            }
        }
        // Removing and returning element
        if (res != null) {
            list.remove(0);
        }
        return res;
    }
    
}

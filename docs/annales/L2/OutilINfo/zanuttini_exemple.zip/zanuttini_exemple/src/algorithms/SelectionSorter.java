package algorithms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * A class implementing selection sort for collections of integers.
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public class SelectionSorter extends AbstractIntegerSorter {

    /**
     * Builds a new instance.
     * @param objects The collection of integers to sort
     */
    public SelectionSorter(Collection<Integer> objects) {
        super(objects);
    }

    @Override
    public void sort() {
        if (super.sortedObjects != null) {
            // Result has already been computed
            return;
        } else {
            // Perform computation
            super.sortedObjects = new ArrayList<>();
            List<Integer> copy = new ArrayList<>(super.objects);
            while ( ! copy.isEmpty() ) {
                Integer element = SelectionSorter.findAndRemoveMinimum(copy);
                super.sortedObjects.add(element);
            }
        }
    }

    /**
     * Removes the minimum integer from a given list. It is assumed that
     * the list is empty, but for efficiency reasons this is not checked.
     * @param objects A list of integers
     * @return The minimum integer of the list
     */
    private static Integer findAndRemoveMinimum(List<Integer> objects) {
        // Minimal element found so far
        Integer res = null;
        // Index of minimal element found so far (ignored if res is null)
        int index = -1;
        // Index of current element
        int currentIndex = 0;
        // Search
        for (Integer element: objects) {
            if (res == null || element < res) {
                res = element;
                index = currentIndex;
            }
            currentIndex++;
        }
        // Removing and returning element
        objects.remove(index);
        return res;
    }

}

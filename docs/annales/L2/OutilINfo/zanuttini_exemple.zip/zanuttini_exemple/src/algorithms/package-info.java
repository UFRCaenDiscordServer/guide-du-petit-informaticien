/**
 * A package providing algorithms for sorting collections
 * of integers.
 */
package algorithms;

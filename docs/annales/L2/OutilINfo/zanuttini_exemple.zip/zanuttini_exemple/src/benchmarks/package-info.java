/**
 * A package providing an executable class for benchamrking
 * the running time of sorting algorithms in package
 * {@link algorithms}.
 */
package benchmarks;

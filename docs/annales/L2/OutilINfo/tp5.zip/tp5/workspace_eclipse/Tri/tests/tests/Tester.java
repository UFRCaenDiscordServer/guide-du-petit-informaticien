package tests;

import java.util.Collection;
import java.util.List;

import algorithms.IntegerSorter;

/**
 * A class for providing methods for running tests on sorting algorithms of
 * package {@link algorithms}. An instance is intended to be used
 * for testing one instance of sorter (hence one algorithm and one collection
 * of objects to sort).
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public class Tester {

    /** The sorter to test. */
    protected IntegerSorter sorter;
    
    /**
     * Builds a new instance.
     * @param sorter The sorter to test
     */
    public Tester(IntegerSorter sorter) {
        this.sorter = sorter;
    }
    
    /**
     * Runs all tests. A successful test means that the result of sorting
     * is exactly the expected one.
     * @return true if the tests pass, false otherwise
     */
    public boolean test() {
        this.sorter.sort();
        Collection<Integer> objects = this.sorter.getObjects();
        List<Integer> sortedList = this.sorter.getSortedList();
        return Tester.isSorted(sortedList) && Tester.areSameMultisets(objects, sortedList);
    }
    
    /**
     * Decides whether a given list of integers is sorted.
     * @param list A list of integers
     * @return true if the list is sorted, false otherwise
     */
    public static boolean isSorted(List<Integer> list) {
        Integer previous = null;
        for (Integer element: list) {
            if (previous != null && element < previous) {
                return false;
            }
            previous = element;
        }
        return true;
    }
    
    /**
     * Decides whether two given collections contain the same integers,
     * each with the same number of occurrences.
     * @param collection A collection of integers
     * @param other Another collection of integers
     * @return true if the two collections are the same multisets,
     * false otherwise
     */
    public static boolean areSameMultisets(Collection<Integer> collection, Collection<Integer> other) {
        // Collections must have the same size
        if (collection.size() != other.size()) {
            return false;
        }
        // Checking all elements with their number of occurrences
        for (Integer element: collection) {
            // Element is in collection, checking in other
            if ( ! other.contains(element) ) {
                return false;
            }
            // Removing occurrence in other
            other.remove(element);
        }
        // collection has been emptied, checking other
        if ( ! other.isEmpty() ) {
            return false;
        }
        // All tests have been passed
        return true;
    }
    
}

package tests;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import algorithms.IntegerSorter;
import algorithms.MergeSorter;
import algorithms.SelectionSorter;
import fr.unicaen.listgenerators.RandomCollectionGenerator;

/**
 * An executable class for running random tests on sorting algorithms of
 * package {@link algorithms}. If a test fails, a message is printed to
 * standard error and the program exits with code 1.
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public class Main {

    /** The list of valid names for sorters (as arguments to the program). */
    public static List<String> sorters = Arrays.asList("selection", "merge-2", "merge-10");

    /**
     * Runs the class
     * @param args args[0] should be a keyword in {@link #sorters}, args[1]
     * should parse to a number of elements on which to test the algorithms,
     * and args[2] may be absent, or parse to a random seed (long)
     */
    public static void main (String [] args) {

        if ( (args.length != 2 && args.length != 3) || ! sorters.contains(args[0])) {
            System.err.print("Usage: " + Main.class.getCanonicalName());
            System.err.println(" <sortingMethod> nbElements [randomSeed]");
            System.err.println("Where sortingMethod is a keyword among " + sorters);
            System.exit(1);
        }

        // Retrieving number of elements
        int nbElements = 0;
        try {
            nbElements = Integer.parseInt(args[1]);
        } catch (Exception e) {
            System.err.println("Cannot parse number of elements from \"" + args[1] + "\"");
            System.exit(1);
        }

        // Drawing or retrieving seed for random generator
        long seed = 0L;
        if (args.length == 2) {
            seed = new Random().nextLong();
        } else {
            assert args.length == 3;
            try {
                seed = Long.parseLong(args[2]);
            } catch (Exception e) {
                System.err.println("Cannot parse seed from \"" + args[2] + "\"");
                System.exit(1);
            }
        }
        System.out.println("Random seed: " + seed);

        // Running test
        RandomCollectionGenerator generator = new RandomCollectionGenerator(seed, -1000, +1000);
        Collection<Integer> objects = generator.next(nbElements);
        IntegerSorter sorter = Main.getSorter(args[0], objects);
        Tester tester = new Tester(sorter);
        if ( ! tester.test() ) {
            System.err.println("Test failed");
            System.exit(1);
        } else {
            System.out.println("Test passed");
        }
    }

    /**
     * Returns an instance of sorter corresponding to the type
     * given by a keyword (in {@link #sorters}) and built with a given
     * collection of objects. 
     * @param keyword A keyword for a type of sorter
     * @param objects A collection of objects to sort
     * @return A sorter
     */
    private static IntegerSorter getSorter (String keyword, Collection<Integer> objects) {
        if ("selection".equals(keyword)) {
            return new SelectionSorter(objects);
        } else if ("merge-2".equals(keyword)) {
            return new MergeSorter(objects, 2);
        } else if ("merge-10".equals(keyword)) {
            return new MergeSorter(objects, 10);
        } else {
            assert false;
            throw new RuntimeException("Unknown keyword for sorter: \"" + keyword + "\"");
        }
    }

}

package algorithms;

import java.util.Collection;
import java.util.List;

/**
 * An interface for algorithms able to sort a collection of
 * integers. It is intended that for a class which implements
 * this interface, an instance is built for each collection of
 * integers to sort.
 * <p>
 * As a general rule, implementation classes are intended to cache
 * the result of sorting so that the sort is effectively performed
 * only on the first call to {@link #sort()}. This can however not
 * be enforced by this interface.
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public interface IntegerSorter {

    /**
     * Sorts the collection of objects of this instance. 
     */
    public void sort();

    /**
     * Returns the (unsorted) collection of objects of this instance.
     * @return The collection of objects of this instance
     */
    public Collection<Integer> getObjects();
    
    /**
     * Returns a sorted list containing the same (multiset of) objects
     * as the collection of this instance, providing {@link #sort()} has been
     * previously called. Several calls are intended to
     * yield the same instance.
     * @return A sorted list with the objects of the collection of this instance
     * @throws IllegalStateException if {@link #sort()} has not been previously called
     */
    public List<Integer> getSortedList() throws IllegalStateException;

}

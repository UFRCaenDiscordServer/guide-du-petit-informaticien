package benchmarks;

import java.util.Arrays;
import java.util.Collection;
import java.util.Random;

import algorithms.IntegerSorter;
import algorithms.MergeSorter;
import algorithms.SelectionSorter;
import fr.unicaen.listgenerators.RandomCollectionGenerator;

/**
 * An executable class for running various sorting algorithms
 * on a random collection of integers of a given size, and printing
 * computation time for each to standard output. All algorithms are
 * run on the same collection, which consists of nb integers drawn
 * at random in [0, nb[, possibly with duplicates.
 * @author Bruno Zanuttini, Université de Caen Normandie
 */
public class Main {

    /**
     * Runs the class.
     * @param args args[0] must parse to the size (positive integer) of
     * the list to run the algorithms with
     */
    public static void main (String [] args) {
        
        if (args.length != 1) {
            System.err.println("Usage: " + Main.class.getCanonicalName() + " nbElements");
            System.exit(1);
        }
        
        // Retrieving number of elements
        int nbElements = -1;
        try {
            nbElements = Integer.parseInt(args[0]);
        } catch (Exception e) {
            System.err.println("Cannot parse number of elements from \"" + args[0] + "\"");
            System.exit(1);
        }
        if (nbElements <= 0) {
            System.err.println("Number of elements must be (strictly) positive");
            System.exit(1);
        }
        System.out.println("[INFO] Number of elements: " + nbElements);
        
        // Drawing collection
        long seed = new Random().nextLong();
        System.out.println("[INFO] Seed: " + seed);
        Random random = new Random(seed);
        RandomCollectionGenerator generator = new RandomCollectionGenerator(random, 0, nbElements);
        Collection<Integer> objects = generator.next(nbElements);
        
        // Running algorithms
        Main.run(new SelectionSorter(objects), "selection");
        for (Integer nbSubcollections: Arrays.asList(2,3,4,5,6)) {
            String name = "merge-"+nbSubcollections;
            Main.run(new MergeSorter(objects, nbSubcollections), name);
        }

    }

    /**
     * Runs a given sorter and prints computation time to standard output.
     * Note that {@link IntegerSorter#sort()} must not have been called before
     * on this sorter, or the result will make little sense if caching of results
     * is used. 
     * @param sorter A sorter
     * @param name The name of the sorter, as should be printed out
     */
    public static void run (IntegerSorter sorter, String name) {
        long startTime = System.currentTimeMillis();
        sorter.sort();
        System.out.println(name + ": "+ (System.currentTimeMillis() - startTime) + " ms");
    }

}

#!/bin/sh

cd $(dirname $0)/..
sh scripts/install.sh
[ -d build ] || mkdir build
javac -d build -cp ".:lib/*" src/*/*.java
javac -d build -cp ".:build:lib/*" tests/*/*.java

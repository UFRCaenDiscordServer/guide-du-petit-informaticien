#!/bin/sh

cd $(dirname $0)/..
rm -rf build jar doc


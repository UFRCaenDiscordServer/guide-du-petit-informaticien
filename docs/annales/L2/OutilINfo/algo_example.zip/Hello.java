public class Hello {

	public static void main (String [] args) {
		//on affiche bonjour
		System.out.println("Bonjour");
	}
}

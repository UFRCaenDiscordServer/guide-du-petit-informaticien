package transportation;

/**
 * A class for representing employees of a transportation company.
 */
public class Employee implements Weighable {

    /** This employee's name. */
    private String name;

    /** This employee's weight, in kilograms. */
    private float weight;

    /**
     * Builds a new instance.
     * @param name The employee's name
     * @param weight The employee's weight, in kilograms
     */
    public Employee (String name, float weight) {
        this.name = name;
        this.weight = weight;
    }

    /**
     * Builds a new instance, with a default weight of 100 kg.
     * @param name The employee's name
     */
    public Employee (String name) {
        this(name, 100);
    }

    /**
     * Returns this employee's name.
     * @return This employee's name
     */
    public String getName () {
        return this.name;
    }

    @Override
    public float getWeight () {
        return this.weight;
    }

}

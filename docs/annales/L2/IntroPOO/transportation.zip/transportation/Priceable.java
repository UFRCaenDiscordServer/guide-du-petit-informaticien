package transportation;

/**
 * An interface for entities which have a price. The interface
 * distinguishes the price (exclusive of tax) and the amount of
 * a tax. The interface does not have a notion of currency,
 * hence if an application uses prices in different currencies,
 * this must be handled aside.
 */
public interface Priceable {

    /**
     * Returns the price of this entity, exclusive of tax.
     * @return The price of this entity, exclusive of tax
     */
    public float getPrice ();

    /**
     * Returns the amount of tax for this entity.
     * @return The amount of tax for this entity
     */
    public float getTaxAmount ();

}

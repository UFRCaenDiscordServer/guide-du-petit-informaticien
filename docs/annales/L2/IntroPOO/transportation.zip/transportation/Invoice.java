package transportation;

import java.util.ArrayList;
import java.util.Collection;

/**
 * A class for representing invoices for a transportation and
 * delivery service. The invoice takes into account the products delivered
 * as well as the cost of transportation.
 */
public class Invoice {

    /** The collection of all elements contributing to this invoice. */
    private Collection<Priceable> elements;

    /**
     * Builds a new instance. The price for all items and for transportation
     * are assumed to be expressed in the same currency, and so will the total
     * price for this invoice.
     * @param items The items contributing to this invoice
     * @param transportationCost The cost for transportation
     * @param transportationTaxAmount The amount of tax for transportation
     */
    public Invoice (Collection<Priceable> items, float transportationCost, float transportationTaxAmount) {
        this.elements = new ArrayList<> ();
        this.elements.addAll(items);
        this.elements.add(new Service ("Transportation", transportationCost, transportationTaxAmount));
    }

    /**
     * Adds an element to this invoice. The same element may be added several
     * times. The currency in which the price of this element is expressed
     * is assumed to be the same as for all other items and for the transportation
     * cost.
     * @param element An element
     */
    public void addElement (Priceable element) {
        this.elements.add(element);
    }

    /**
     * Returns the total amount of this invoice, including tax.
     * @return The total amount of this invoice, including tax
     */
    public float getPrice () {
        float res = 0;
        for (Priceable element: this.elements) {
            res+= element.getPrice() + element.getTaxAmount();
        }
        return res;
    }

}

package transportation;

/**
 * A class for representing products as transported and sold by a
 * transportation company.
 */
public class Product implements Weighable, Priceable {

    /** The description of this product. */
    private String description;

    /** The weight of this product, in kilograms. */
    private float weight;

    /** The price of this product, exclusive of tax. */
    private float price;

    /** The amount of tax for this product. */
    private float taxAmount;

    /**
     * Builds a new instance.
     * @param description The description of this product
     * @param weight The weight of this product, in kilograms
     * @param price The price of this product, exclusive of tax
     * @param taxAmount The amount of tax for this product
     */
    public Product (String description, float weight, float price, float taxAmount) {
        this.description = description;
        this.weight = weight;
        this.price = price;
        this.taxAmount = taxAmount;
    }

    /**
     * Returns the description of this product.
     * @return The description of this product
     */
    public String getDescription () {
        return this.description;
    }

    @Override
    public float getWeight () {
        return this.weight;
    }

    @Override
    public float getPrice () {
        return this.price;
    }

    @Override
    public float getTaxAmount () {
        return this.taxAmount;
    }

}

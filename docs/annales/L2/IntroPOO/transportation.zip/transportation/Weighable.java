package transportation;

/**
 * An interface for entities which have a weight.
 */
public interface Weighable {

    /**
     * Returns the weight of this entity, in kilograms.
     * @return The weight of this entity, in kilograms
     */
    public float getWeight ();

}

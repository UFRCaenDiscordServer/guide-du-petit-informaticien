package transportation;

import java.util.ArrayList;
import java.util.List;

/**
 * A class for representing packs of products as transported and sold by a
 * transportation company.
 */
public class Pack implements Weighable, Priceable {

    /** The collection of products in this package. */
    private List<Product> products;

    /**
     * Builds a new instance, with no product.
     */
    public Pack () {
        this.products = new ArrayList<> ();
    }

    /**
     * Adds a product to this package. The same
     * product can be added several times.
     * @param product A product
     */
    public void add (Product product) {
        this.products.add(product);
    }

    /**
     * Returns the list of all products in this package.
     * @return The list of all products in this package
     */
    public List<Product> getProducts () {
        return this.products;
    }

    @Override
    public float getWeight () {
        float res = 0;
        for (Product product: this.products) {
            res+= product.getWeight();
        }
        return res;
    }

    @Override
    public float getPrice () {
        float res = 0;
        for (Product product: this.products) {
            res+= product.getPrice();
        }
        return res;
    }

    @Override
    public float getTaxAmount () {
        float res = 0;
        for (Product product: this.products) {
            res+= product.getTaxAmount();
        }
        return res;
    }

}

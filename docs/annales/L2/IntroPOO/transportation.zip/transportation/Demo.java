package transportation;

import java.util.ArrayList;
import java.util.Collection;

/**
 * An executable class for demonstrating the use of this package.
 */
public class Demo {

    public static void main (String [] args) {

        System.out.println("");

        // A box of pasta weighing 170 g and costing 3 € + 50 cts tax
        Product pasta = new Product ("Pasta box", 0.175f, 3, 0.5f);

        // A napkin weighing 10 g and costing 10 cts + 2 cts tax
        Product napkin = new Product ("Napkin", 0.004f, 0.1f, 0.02f);

        System.out.println("Une pasta box pèse " + (pasta.getWeight() * 1000) + " g.");
        System.out.println("Une serviette pèse " + (napkin.getWeight() * 1000) + " g.");
        System.out.println("Le prix d'une pasta box est de " + pasta.getPrice() + " € + " + pasta.getTaxAmount() + " € de taxes.");
        System.out.println("Le prix d'une serviette est de " + napkin.getPrice() + " € + " + napkin.getTaxAmount() + " € de taxes.");

        System.out.println("");

        // A pack containing a number of pasta boxes and the same number of napkins
        int nbBoxes = 200;
        Pack pastaPack = new Pack ();
        for (int i = 0; i < nbBoxes; i++) {
            pastaPack.add(pasta);
            pastaPack.add(napkin);
        }

        // Two drivers
        Employee fatsDomino = new Employee ("Fats Domino", 210);
        Employee paolo = new Employee ("Paolo");

        // A 36-ton truck transporting a number of packs of pasta
        int nbPacks = 1000;
        Truck truck = new Truck (36);
        Collection<Priceable> allPacks = new ArrayList<> ();
        Collection<Weighable> load = new ArrayList<> ();
        for (int i = 0; i < nbPacks; i++) {
            truck.add(pastaPack);
            allPacks.add(pastaPack);
            load.add(pastaPack);
        }

        System.out.println("Un 36 tonnes peut-il transporter " + nbPacks + " cartons de " + nbBoxes + " pasta box ?");
        System.out.println("");

        // Setting driver to Fats Domino
        truck.setDriver(fatsDomino);
        load.add(fatsDomino);
        System.out.print("- Conduit par " + fatsDomino.getName() + ", qui pèse " + fatsDomino.getWeight() + " kg ? ");
        if (truck.canTransport(load)) {
            System.out.println("oui");
        } else {
            System.out.println("non");
        }

        // Changing driver to Paolo
        truck.setDriver(paolo);
        load.remove(fatsDomino);
        load.add(paolo);
        System.out.print("- Conduit par " + paolo.getName() + ", qui pèse " + paolo.getWeight() + " kg ? ");
        if (truck.canTransport(load)) {
            System.out.println("oui");
        } else {
            System.out.println("non");
        }

        System.out.println("");

        // The corresponding invoice, with transportation cost 500 € + 20 € tax
        Invoice invoice = new Invoice (allPacks, 500, 20);
        System.out.println("Prix total, transport et taxes inclus : " + invoice.getPrice());

        System.out.println("");

    }

}

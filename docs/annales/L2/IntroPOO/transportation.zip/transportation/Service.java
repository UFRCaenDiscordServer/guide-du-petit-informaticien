package transportation;

/**
 * A class for representing services as sold by a transportation company.
 */
public class Service implements Priceable {

    /** The description of this service. */
    private String description;

    /** The price of this service, exclusive of tax. */
    private float price;

    /** The amount of tax for this service. */
    private float taxAmount;

    /**
     * Builds a new instance.
     * @param description The description of this service
     * @param price The price of this service, exclusive of tax
     * @param taxAmount The amount of tax for this service
     */
    public Service (String description, float price, float taxAmount) {
        this.description = description;
        this.price = price;
        this.taxAmount = taxAmount;
    }

    /**
     * Returns the description of this service.
     * @return The description of this service
     */
    public String getDescription () {
        return this.description;
    }

    @Override
    public float getPrice () {
        return this.price;
    }

    @Override
    public float getTaxAmount () {
        return this.taxAmount;
    }

}

package transportation;

import java.util.ArrayList;
import java.util.Collection;

/**
 * A class for representing a truck with its driver and load.
 */
public class Truck {

    /** The maximal load for this truck, in kilograms. */
    private int maximalLoad;

    /** The driver for this truck (null if none assigned). */
    private Employee driver;

    /** The collection of packages transported by this truck. */
    private Collection<Pack> load;

    /**
     * Builds a new instance, with no driver assigned and an empty load.
     * @param maximalLoad The maximal load allowed for this truck, in tons.
     */
    public Truck (int maximalLoad) {
        // Converting tons to kilograms
        this.maximalLoad = maximalLoad * 1000;
        this.driver = null;
        this.load = new ArrayList<> ();
    }

    /**
     * Assigns a driver to this truck. Replaces the driver previously
     * assigned, if any.
     * @param driver The new driver for this truck
     */
    public void setDriver (Employee driver) {
        this.driver = driver;
    }

    /**
     * Adds a package to the load of this truck. The same package may
     * be added several times.
     * @param pack A package
     */
    public void add (Pack pack) {
        this.load.add(pack);
    }

    /**
     * Decides whether this truck can transport a given collection
     * of entities (whatever they are) according to its maximal load.
     * @param entities A collection of entities
     * @return true if the maximal load allowed for this truck allows
     * it to transport the given collection of entities, false otherwise
     */
    public boolean canTransport (Collection<Weighable> entities) {
        float totalWeight = 0;
        for (Weighable entity: entities) {
            totalWeight+= entity.getWeight();
        }
        return totalWeight < this.maximalLoad;
    }

}

package redundancy;

import java.util.HashSet;
import java.util.Set;

/**
 * An executable class which reads arguments and prints them out after
 * removing duplicates.
 */
public class Demo {

    /**
     * Runs the demo.
     * @param args As many string as desired
     */
    public static void main(String[] args) {
        Set<String> unique = new HashSet<>();
        for (String arg: args) {
            unique.add(arg);
        }
        System.out.print("Arguments, une seule fois chacun :");
        for (String arg: unique) {
            System.out.print(" " + arg);
        }
        System.out.println();
    }
    
}

package groups;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Set;

/**
 * A class representing group makers, which are able to split collections
 * of elements into balanced groups.
 */
public class GroupMaker {

    /**
     * Makes balanced groups of elements from a given collection. The smallest
     * size at least equal to 2 allowing this is used.
     * @param elements A collection of elements
     * @return A list of sets of elements, where each set represents a group
     */
    public static Collection< Set<String> > makeBalancedGroups (Collection<String> elements) {

        // Computing group size
        int nb = elements.size();
        int groupSize = 2;
        while (nb % groupSize != 0) {
            // While-loop is guaranteed to terminate, at worst
            // when groupSize == nb
            groupSize++;
        }

        // Computing groups
        Collection< Set<String> > res = new ArrayList<> ();
        Set<String> currentGroup = null;

        // Choose between one of these
        currentGroup = new TreeSet<> ();
        //currentGroup = new HashSet<> ();

        for (String element: elements) {
            currentGroup.add(element);
            if (currentGroup.size() == groupSize) {
                res.add(currentGroup);
                // Choose between one of these
                currentGroup = new HashSet<> ();
                //currentGroup = new TreeSet<> ();
            }
        }

        return res;
        
    }

}

package groups;

import java.util.Collection;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * An executable class for demonstrating the use of interfaces and classes
 * of the java Collections framework.
 */
public class Demo {

    /**
     * Generates a number of students (as strings) and splits them into balanced groups,
     * for different numbers.
     * @param args ignored
     */
    public static void main (String [] args) {
        System.out.println("");
        Demo.runDemo(0);
        System.out.println("");
        Demo.runDemo(6);
        System.out.println("");
        Demo.runDemo(7);
        System.out.println("");
        Demo.runDemo(25);
        System.out.println("");
    }

    /**
     * Generates a given number of students (as strings) and splits them into balanced groups.
     * @param nb A number of students
     */
    public static void runDemo (int nb) {

        System.out.println("Nombre d'étudiants : " + nb);

        // Generating students and computing groups
        Set<String> students = Demo.generate(nb);
        GroupMaker groupMaker = new GroupMaker ();
        Collection< Set<String> > groups = groupMaker.makeBalancedGroups(students);

        // Displaying groups
        if (groups.isEmpty()) {
            // Special case: no group
            System.out.println("Aucun groupe");
        } else {
            // At least one group
            System.out.println( groups.size() == 1 ? "Groupe :" : "Groupes :" );
            for (Set<String> group: groups) {
                System.out.print("- ");
                String separator = "";
                for (String student: group) {
                    System.out.print(separator + student);
                    separator = ", ";
                }
                System.out.println("");
            }
            
        }
    }

    /**
     * Generates a given number of students at random, as strings of the form "etu_id" with
     * id a 4-digit number uniformly drawn in [1000..9999].
     * @param nb The number of students to generate
     * @return A set of randomly generated students
     */
    public static Set<String> generate (int nb) {
        Random random = new Random ();
        int maxNb = nb * nb;
        Set<String> res = new HashSet<> ();
        int nbGenerated = 0;
        while (nbGenerated < nb) {
            String student = "etu_" + (1000 + random.nextInt(8999));
            boolean added = res.add(student);
            if (added) {
                nbGenerated++;
            }
        }
        return res;
    }

}

package sorting;

/**
 * A class for representing a student.
 */
public class Student implements Comparable<Student> {

    /** The student's first name. */
    protected String firstName;

    /** The student's last name. */
    protected String lastName;

    /** The student's numerical id. */
    protected long studentId;

    /**
     * Buidls a new instance.
     * @param firstName The student's first name
     * @param lastName The student's last name
     * @param studentId The student's numerical id
     */
    public Student(String firstName, String lastName, long studentId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.studentId = studentId;
    }

    /**
     * Returns this student's first name.
     * @return This student's first name
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * Returns this student's last name.
     * @return This student's last name
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * Returns this student's numerical id.
     * @return This student's numerical id
     */
    public long getStudentId() {
        return this.studentId;
    }

    @Override
    public String toString() {
        return this.firstName + " " + this.lastName + " (" + this.studentId + ")";
    }

    @Override
    public int compareTo(Student other) {
        return this.lastName.compareTo(other.lastName);
    }
    
}

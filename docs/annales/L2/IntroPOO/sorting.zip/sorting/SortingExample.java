package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * An executable class demonstrating the sorting of a list
 * of students.
 */
public class SortingExample {

    /**
     * Runs the example.
     * @param args ignored
     */
    public static void main(String[] args) {
        
        ArrayList<Student> allStudents = new ArrayList<>();
        allStudents.add(new Student("Kevin", "Durand", 20123456));
        allStudents.add(new Student("Lea", "Dupont", 21234567));
        allStudents.add(new Student("Louane", "Martin", 22345678));
        allStudents.add(new Student("Pierre", "Lefebvre", 23456789));
        allStudents.add(new Student("Marie", "Dubois", 24567890));
        
        System.out.println();

        System.out.println("Liste de tous les étudiants, non triée :");
        System.out.println();
        SortingExample.print(allStudents);
        
        Collections.sort(allStudents);
        
        System.out.println();
        
        System.out.println("Liste de tous les étudiants, après tri :");
        System.out.println();
        SortingExample.print(allStudents);       

        System.out.println();
        
    }

    /**
     * Pretty prints a list of students to standard output.
     * @param students A list of students
     */
    private static void print(ArrayList<Student> students) {
        for (Student student: students) {
            System.out.println("- " + student);
        }
    }
    
}

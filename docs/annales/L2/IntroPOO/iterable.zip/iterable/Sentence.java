package iterable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A class for representing a sentence as, essentially, a list of words.
 */
public class Sentence implements Iterable<String> {

    /** The list of words in this sentence. */
    protected List<String> words;

    /**
     * Builds a new instance with no word.
     */
    public Sentence() {
        this.words = new ArrayList<>();
    }

    /**
     * Adds a word to the end of this sentence.
     * @param word A word
     */
    public void addWord(String word) {
        this.words.add(word);
    }

    @Override
    public String toString() {
        StringBuilder res = new StringBuilder();
        String sep = "";
        for (String word: this.words) {
            res.append(sep);
            res.append(word);
            sep = " ";
        }
        res.append(".");
        return res.toString();
    }

    @Override
    public Iterator<String> iterator() {
        return this.words.iterator();
    }

}

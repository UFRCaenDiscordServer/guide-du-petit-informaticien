package iterable;

/**
 * A class for testing the class {@link Sentence}.
 */
public class Test {

    /**
     * Runs the test.
     * @param args ignored
     */
    public static void main(String[] args) {
        Sentence sentence = new Sentence();
        sentence.addWord("Le");
        sentence.addWord("petit");
        sentence.addWord("chat");
        sentence.addWord("mange");
        sentence.addWord("la");
        sentence.addWord("souris");
        System.out.println("Phrase : " + sentence.toString());
        System.out.print("Nombres de lettres :");
        for (String word: sentence) {
            System.out.print(" " + word.length());
        }
        System.out.println();
    }
    
}

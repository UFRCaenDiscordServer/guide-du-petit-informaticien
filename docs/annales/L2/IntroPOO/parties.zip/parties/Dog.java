package parties;

/**
 * A class for representing dogs, seen as polite pets.
 */
public class Dog extends Pet implements Polite {

    /**
     * Builds a new instance.
     * @param name The dog's name
     * @param color The dog's color
     */
    public Dog(String name, String color) {
        super(name, color);
    }
    
    @Override
    public String hello() {
        return "Ouaf";
    }

    @Override
    public String goodbye() {
        return "Ouaf ouaf";
    }

    @Override
    public String cry() {
        return "Ouaf";
    }

}

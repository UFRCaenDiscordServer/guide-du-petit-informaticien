package parties;

/**
 * A class for representing children (considered to be polite).
 */
public class Child implements Polite {

    /** The child's name. */
    protected String name;
    
    /**
     * Builds a new instance.
     * @param name The child's name
     */
    public Child(String name) {
        this.name = name;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public String hello() {
        return "Bonjour";
    }

    @Override
    public String goodbye() {
        return "Au revoir";
    }

}

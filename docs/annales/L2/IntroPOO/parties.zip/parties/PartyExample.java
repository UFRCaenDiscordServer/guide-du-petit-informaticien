package parties;

/**
 * An executable class for demonstrating the use of this package.
 */
public class PartyExample {

    /**
     * Runs the demo.
     * @param args ignored
     */
    public static void main (String[] args) {

        Child kevin = new Child("Kevin Martin");
        Child lea = new Child("Lea Dupont");
        Child louane = new Child("Louane Durand");
        Dog max = new Dog("Max", "brun");

        Party party = new Party();
        System.out.println();
        
        party.join(kevin);
        party.join(lea);
        System.out.println();
        party.describe();
        System.out.println();
        party.join(louane);
        party.join(max);
        System.out.println();
        party.describe();

        System.out.println();

        party.leave(max);
        System.out.println();
        party.describe();
        System.out.println();
        party.leave(kevin);
        party.leave(louane);
        party.leave(lea);
        System.out.println();
        party.describe();

    }
    
}

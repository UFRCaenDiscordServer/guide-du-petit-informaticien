package parties;

/**
 * An abstract class for representing (mammal) pets, with their
 * name and color.
 */
public abstract class Pet {

    /** The pet's name. */
    protected String name;
    
    /** The pet's color. */
    protected String color;
    
    /**
     * Builds a new instance.
     * @param name The pet's name
     * @param color The pet's color
     */
    public Pet(String name, String color){
        this.name = name;
        this.color = color;
    }
    
    /**
     * Returns a string representing the name of this pet, plus indication
     * about its color.
     * @return A string representing this pet
     */
    public String getName() {
        return this.name + " (poil " + this.color + ")";
    }

    /**
     * Returns a string representing this pet's typical cry.
     * @return A string representing this pet's typical cry
     */
    public abstract String cry();
    
}

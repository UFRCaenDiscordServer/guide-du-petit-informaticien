package parties;

/**
 * An interface for polite beings, which have a name and are able to say hello
 * and goodbye.
 */
public interface Polite {

    /**
     * Returns this being's name, as a string.
     * @return This being's name
     */
    public String getName();

    /**
     * Returns a string representing what this being utters for saying hello.
     * @return A string representing what this being utters for saying hello
     */
    public String hello();

    /**
     * Returns a string representing what this being utters for saying goodbye.
     * @return A string representing what this being utters for saying goodbye
     */
    public String goodbye();

}

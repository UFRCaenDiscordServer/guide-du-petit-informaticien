package parties;

/**
 * A class for representing (pet) cats.
 */
public class Cat extends Pet {

    /**
     * Builds a new instance.
     * @param name The cat's name
     * @param color The cat's color
     */
    public Cat(String name, String color) {
        super(name, color);
    }

    @Override
    public String cry() {
        return "Miaou";
    }

}

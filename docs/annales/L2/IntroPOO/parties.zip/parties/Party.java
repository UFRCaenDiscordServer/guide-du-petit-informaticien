package parties;

import java.util.ArrayList;

/**
 * A class for representing a party which polite attenders can join or leave.
 * Hellos and goodbyes are printed to standard output whenever one joins or
 * leaves the party.
 */
public class Party {

    /** The current list of all attenders. */
    private ArrayList<Polite> attenders;

    /**
     * Builds a new party with noone attending, and notifies this on standard
     * output.
     */
    public Party() {
        System.out.println("Une fête commence");
        this.attenders = new ArrayList<>();
    }

    /**
     * Makes a new attender join the party. If the attender
     * is already attending, nothing occurs.
     * @param attender A polite attender
     */
    public void join(Polite attender) {
        if ( ! this.attenders.contains(attender)) {
            this.attenders.add(attender);
            System.out.println(attender.hello());
        }
    }

    /**
     * Makes an attender leave the party. If the attender
     * was not attending the party, nothing occurs.
     * @param attender A polite attender
     */
    public void leave(Polite attender) {
        if (this.attenders.contains(attender)) {
            System.out.println(attender.goodbye());
            this.attenders.remove(attender);
        }
    }

    /**
     * Prints a description of the current attendance to
     * standard output.
     */
    public void describe() {
        if (this.attenders.isEmpty()) {
            System.out.println("Il n'y a plus personne à la fête");
        } else {
            System.out.println("La fête compte :");
            for (Polite attender : this.attenders) {
                System.out.println("- " + attender.getName());
            }
        }
    }

}

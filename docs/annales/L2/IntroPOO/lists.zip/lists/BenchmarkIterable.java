package lists;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;

public class BenchmarkIterable {

	public static void main (String [] args) {
		int nbElements = 0;
		try {
			nbElements = Integer.parseInt(args[0]);
		} catch (Exception e) {
			System.out.println("Usage: java " + BenchmarkIterable.class.getCanonicalName() + " nbElements");
			System.exit(1);
		}
		System.out.println("ArrayList...");
		BenchmarkIterable.test(new ArrayList<>(), nbElements);
		System.out.println("LinkedList...");
		BenchmarkIterable.test(new LinkedList<>(), nbElements);
	}

	private static void test(List<String> list, int nbElements) {
		for (int i = 0; i < nbElements; i++) {
			list.add("element #" + i);
		}
		long start = System.currentTimeMillis();
		long sum = 0L;
		for (String element: list) {
			sum += element.length();
		}
		long end = System.currentTimeMillis();
		System.out.println("Sum of lengthes: " + sum);
		System.out.println("Time: " + (end - start) + " ms");
	}

}

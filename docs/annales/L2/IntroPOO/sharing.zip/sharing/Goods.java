package sharing;

import java.util.ArrayList;

/**
 * A class for representing sets of goods.
 */
public class Goods implements Sharable {

    /** The set of goods itself. */
    private ArrayList<Sharable> goods;
    
    /**
     * Builds a new instance with no good.
     */
    public Goods() {
        this.goods = new ArrayList<>();
    }
    
    /**
     * Adds a good to this instance. The good is added even if
     * already present in this instance.
     * @param good A good
     */
    public void addGood(Sharable good) {
        this.goods.add(good);
    }
    
    @Override
    public Sharable share(int nbPersons) {
        Goods res = new Goods();
        for (Sharable good: this.goods) {
            res.addGood(good.share(nbPersons));
        }
        return res;
    }
    
    @Override
    public Sharable remainder(int nbPersons) {
        Goods res = new Goods();
        for (Sharable good: this.goods) {
            res.addGood(good.remainder(nbPersons));
        }
        return res;        
    }
    
    @Override
    public String toString() {
        return this.goods.toString();
    }
    
}

package sharing;

/**
 * An interface for objects which can be shared (possibly with a remainder)
 * equitably among a number of persons. As general rules: (1) if an object is shared
 * among 0 person, then the whole object is considered to be the remainder, and
 * (2) a new instance should be returned even if the instance itself could be returned
 * (for instance, when an object is shared among 1 person).
 */
public interface Sharable {

    /**
     * Returns an object representing each person's share when
     * this object is shared among a given number of persons.
     * @param nbPersons A number of persons
     * @return Each person's share
     */
    public Sharable share(int nbPersons);
    
    /**
     * Returns an object representing the remainder when
     * this object is shared among a given number of persons.
     * @param nbPersons A number of persons
     * @return The remainder
     */
    public Sharable remainder(int nbPersons);
    
}

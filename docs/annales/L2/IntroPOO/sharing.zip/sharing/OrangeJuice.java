package sharing;

/**
 * A class for representing quantities of orange juice.
 */
public class OrangeJuice implements Sharable{

    /** The quantity of orange juice in this instance (centiliters). */
    private float quantity;
    
    /**
     * Builds a new instance.
     * @param quantity The quantity of orange juice in this instance (centiliters)
     */
    public OrangeJuice(float quantity){
        this.quantity = quantity;
    }

    /**
     * Returns the quantity of orange juice in this instance.
     * @return The quantity of orange juice in this instance (centiliters)
     */
    public float getQuantity() {
        return this.quantity;
    }
    
    @Override
    public Sharable share(int nbPersons) {
        return new OrangeJuice(this.quantity / nbPersons);
    }

    @Override
    public OrangeJuice remainder(int nbPersons) {
        return new OrangeJuice(0);
    }
    
    @Override
    public String toString() {
        return this.quantity + " cl de jus d'orange"; 
    }
    
}

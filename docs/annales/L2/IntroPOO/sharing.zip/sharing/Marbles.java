package sharing;

/**
 * A class for representing bags of marbles. An instance represents a number of marbles.
 */
public class Marbles implements Sharable{

    /** The number of marbles in this bag. */
    private int nbMarbles;
    
    /**
     * Builds a new instance.
     * @param nbMarbles The number of marbles in this instance
     */
    public Marbles(int nbMarbles){
        this.nbMarbles = nbMarbles;
    }

    /**
     * Returns the number of marbles in this instance.
     * @return The number of marbles in this instance
     */
    public int getNbMarbles() {
        return this.nbMarbles;
    }
    
    @Override
    public Sharable share(int nbPersons) {
        if (nbPersons <= 0) {
            return new Marbles(0);
        } else {
            return new Marbles(this.nbMarbles / nbPersons);
        }
    }

    @Override
    public Marbles remainder(int nbPersons) {
        if (nbPersons <= 0) {
            return new Marbles(this.nbMarbles);
        } else {
            return new Marbles(this.nbMarbles % nbPersons);
        }
    }
    
    @Override
    public String toString() {
        if (this.nbMarbles == 0) {
            return "sac de billes vide";
        } else if (this.nbMarbles == 1) {
            return "sac de 1 bille";
        } else {
            return "sac de " + this.nbMarbles + " billes"; 
        }
    }
    
}

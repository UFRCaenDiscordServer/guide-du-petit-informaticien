package sharing;

/**
 * An executable class for demonstrating the use of this package.
 */
public class SharingExample {

    /**
     * Runs the demo.
     * @param args ignored
     */
    public static void main(String[] args) {
        Goods goods = new Goods();
        goods.addGood(new Marbles(10));
        goods.addGood(new OrangeJuice(35));
        int nbPersons = 3;
        System.out.println("Ensemble des biens : " + goods);
        System.out.println("Partage entre " + nbPersons + " enfants...");
        Sharable share = goods.share(nbPersons);
        Sharable remainder = goods.remainder(nbPersons);
        System.out.println("Chaque enfant reçoit : " + share);
        System.out.println("Il reste : " + remainder);
    }
    
}

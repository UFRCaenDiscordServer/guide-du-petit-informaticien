package greeting;

/**
 * An executable class for demonstrating the use of arguments
 * for the main method.
 */
public class Main {

    /**
     * Runs the application.
     * @param args args[0] is mandatory (should be a first name), and args[1] is
     * optional (should be a last name)
     */
    public static void main (String [] args) {

        // Verifying arguments
        if (args.length != 1 && args.length != 2) {
            System.out.println("");
            System.out.println("Expected one or two arguments.");
            System.out.println("Arguments: first-name [last-name].");
            System.out.println("");
            System.exit(1);
        }

        // Retrieving arguments
        String firstName = args[0];
        String lastName = "X";
        if (args.length == 2) {
            lastName = args[1];
        }

        // Greeting
        System.out.println("");
        System.out.println("Bonjour " + firstName + " " + lastName);
        System.out.println("");

    }

}

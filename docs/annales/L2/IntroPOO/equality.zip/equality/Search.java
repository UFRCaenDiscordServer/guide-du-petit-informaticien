package equality;

import java.util.List;
import java.util.ArrayList;

public class Search {

	public static void main (String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: " + Search.class.getCanonicalName() + " firstName lastName");
			System.exit(1);
		}

		List<Person> persons = new ArrayList<>();
		persons.add(new Person("Jean", "Dupont"));
		persons.add(new Person("Marie", "Durand"));
		persons.add(new Person("John", "Doe"));

 		Person p = new Person(args[0], args[1]);

		if (persons.contains(p)) {
			System.out.println("Cette personne est connue");
		} else {
			System.out.println("Cette personne est inconnue");
		}
	}

}


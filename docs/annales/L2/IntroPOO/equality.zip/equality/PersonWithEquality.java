package equality;

import java.util.Objects;

public class PersonWithEquality extends Person {

	public PersonWithEquality (String firstName, String lastName) {
		super(firstName, lastName);
	}

	@Override
	public boolean equals(Object o) {
		if ( ! (o instanceof PersonWithEquality) ) {
			return false;
		}
		return
			this.firstName.equals(((PersonWithEquality)o).firstName) &&
			this.lastName.equals(((PersonWithEquality)o).lastName);
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.firstName, this.lastName);
	}

}


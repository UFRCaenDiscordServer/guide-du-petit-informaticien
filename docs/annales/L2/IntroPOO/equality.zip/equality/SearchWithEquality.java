package equality;

import java.util.List;
import java.util.ArrayList;

public class SearchWithEquality {

	public static void main (String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: " + Search.class.getCanonicalName() + " firstName lastName");
			System.exit(1);
		}

		List<PersonWithEquality> persons = new ArrayList<>();
		persons.add(new PersonWithEquality("Jean", "Dupont"));
		persons.add(new PersonWithEquality("Marie", "Durand"));
		persons.add(new PersonWithEquality("John", "Doe"));

 		PersonWithEquality p = new PersonWithEquality(args[0], args[1]);

		if (persons.contains(p)) {
			System.out.println("Cette personne est connue");
		} else {
			System.out.println("Cette personne est inconnue");
		}
	}

}


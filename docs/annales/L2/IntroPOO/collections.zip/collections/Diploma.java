package collections;

import java.util.Arrays;

/**
 * A class for representing a diploma, here one year of study. A diploma is made of
 * a name and a school year.
 */
public class Diploma {

    /** The name of this diploma. */
    private String name;

    /** The school year, as a string, e.g., "2017-2018". */
    private String year;

    /**
     * Builds a new instance.
     * @param name The name of this diploma
     * @param year The school year for this diploma, as a string, e.g., "2017-2018"
     */
    public Diploma (String name, String year) {
        this.name = name;
        this.year = year;
    }

    @Override
    public String toString () {
        return this.name + " " + this.year;
    }

    @Override
    public boolean equals (Object other) {
        if ( ! (other instanceof Diploma) ) {
            return false;
        }
        Diploma otherAsDiploma = (Diploma) other;
        return otherAsDiploma.name.equals(this.name) && otherAsDiploma.year.equals(this.year);
    }

    @Override
    public int hashCode () {
        return Arrays.hashCode( new String [] {this.name, this.year} );
    }

}

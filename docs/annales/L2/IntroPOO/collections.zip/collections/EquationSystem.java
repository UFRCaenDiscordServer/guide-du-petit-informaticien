package collections;

/**
 * A class for representing systems of linear equations with floating-point coefficients.
 * We use notation A.x = b for such system, where A is the matrix of coefficients, x is
 * the column vectors of unknowns, and b is the column vector of the rhs's of equations.
 * Equations and unknowns are 0-indexed.
 */
public class EquationSystem {

    /** The matrix A; coefficients[i][j] is the coefficient of x_j in the i-th equation. */
    private float [][] coefficients;

    /** The vector b; rhs[i] is the rhs of the i-th equation. */
    private float[] rhs;

    /** The number of unknowns in this system (stored in case there is no equation). */
    private int nbUnknowns;

    /**
     * Builds a new instance with given numbers of equations and unknowns and
     * coefficient 0 and rhs 0 everywhere.
     * @param nbEquations The number of equations in the system
     * @param nbUnknowns The number of unknowns in the system
     */
    public EquationSystem (int nbEquations, int nbUnknowns) {
        // Initialization to 0 is implicit
        this.coefficients = new float [nbEquations] [nbUnknowns];
        this.rhs = new float [nbEquations];
        this.nbUnknowns = nbUnknowns;
    }

    /**
     * Sets the i-th equation in this system, replacing the previous equation.
     * @param i The index of the equation to set
     * @param coefficients An array of coefficients of the correct length
     * @param rhs The RHS of the equation
     * @throws IllegalArgumentException if the index of the equation or the
     * number of coefficients is wrong
     */
    public void setEquation (int i, float [] coefficients, float rhs) {
        if (i >= this.coefficients.length) {
            throw new IllegalArgumentException ("Incorrect equation index : " + i
                                                + ", expected a number lower than "
                                                + this.coefficients.length);
        }
        if (coefficients.length != this.nbUnknowns) {
            throw new IllegalArgumentException ("Incorrect coefficients : " + coefficients
                                                + ", expected an array of "
                                                + this.nbUnknowns + " coefficients");
        }
        this.coefficients[i] = coefficients;
        this.rhs[i] = rhs;
    }

    /**
     * Returns the number of equations in this system.
     * @return The number of equations in this system
     */
    public int getNbEquations () {
        return this.coefficients.length;
    }

    /**
     * Returns the number of unknowns in this system.
     * @return The number of unknowns in this system
     */
    public int getNbUnknowns () {
        return this.nbUnknowns;
    }

    /**
     * Decides whether a given assignment of values to the unknowns is
     * a solution to this system.
     * @param assignment An assignment of values to the unknowns (assignment[j]
     * is the value for the j-th unknown)
     * @return true if the assignment if a solution to this system, false otherwise
     * @throws IllegalArgumentException if the number of values is different from
     * the number of unknowns in this system
     */
    public boolean isSatisfiedBy (float [] assignment) throws IllegalArgumentException {
        if (assignment.length != this.nbUnknowns) {
            throw new IllegalArgumentException ("Wrong number of values in " + assignment
                                                + ", expected " + this.nbUnknowns);
        }
        float [] lhs = this.computeLHS(assignment);
        for (int i = 0; i < this.coefficients.length; i++) {
            if (lhs[i] != this.rhs[i]) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString () {
        if (this.coefficients.length == 0) {
            return "System consisting of no equation";
        }
        StringBuilder res = new StringBuilder ();
        for (int i = 0; i < this.coefficients.length; i++) {

            // Appending the representation of the i-th equation

            // Coefficients
            boolean oneNonzero = false;
            for (int j = 0; j < this.nbUnknowns; j++) {

                if (this.coefficients[i][j] != 0) {
                    oneNonzero = true;
                }

                if (this.coefficients[i][j] == 1) {
                    res.append("+ x_" + j + " ");
                } else if (this.coefficients[i][j] == -1) {
                    res.append("- x_" + j + " ");
                } else if (this.coefficients[i][j] > 0) {
                    res.append("+ " + this.coefficients[i][j] + " " + "x_" + j + " ");
                } else if (this.coefficients[i][j] < 0) {
                    res.append("- " + (- this.coefficients[i][j]) + " " + "x_" + j + " ");
                    oneNonzero = true;
                } // otherwise, append nothing

            }
            if (! oneNonzero) {
                res.append("0 ");
            }

            // Equal sign and RHS
            res.append("= ");
            res.append(this.rhs[i]);

            res.append(System.lineSeparator());

        }
        return res.toString();
    }

    // Helper methods ==========================================================

    /**
     * Computes the product A v, where A is the matrix of coefficients of this
     * system and v is an assignment of values to the unknowns.
     * @param assignment An assignment of values to the unknowns in this system; the behaviour
     * is undefined if the number of values is different from the number of
     * unknowns
     * @return an array representing the column vector lhs, where lhs[i] is the lhs
     * of the i-th equation under the given assignment
     */
    private float [] computeLHS (float [] assignment) {
        float [] res = new float [this.coefficients.length];
        int i = 0;
        for (float [] equation: this.coefficients) {
            res[i] = EquationSystem.computeDotProduct(equation, assignment);
            i++;
        }
        return res;
    }

    /**
     * Computes the dot product v . v' for two vectors v, v'.
     * @param vector A vector
     * @param other A vector of the same length as vector (otherwise the behaviour
     * is undefined)
     * @return The dot product of vector and other
     */
    private static float computeDotProduct (float [] vector, float [] other) {
        float res = 0;
        for (int i = 0; i < vector.length; i++) {
            res += vector[i] * other[i];
        }
        return res;
    }

}

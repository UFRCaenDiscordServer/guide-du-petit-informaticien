package collections;

import java.util.ArrayList;

/**
 * An executable class for demonstrating the use of ArrayList's.
 */
public class ArrayListDemo {

    /**
     * Runs the demo.
     * @param args ignored
     */
    public static void main (String [] args) {

        System.out.println("");

        // Creates a list of characters and prints it
        ArrayList<Character> exampleList = new ArrayList<> ();
        exampleList.add('a');
        exampleList.add('B');
        exampleList.add('c');
        System.out.println("Liste de caractères : " + exampleList);

        // Prints the element at each index in the list using get
        System.out.println("");
        for (int i = 0; i < exampleList.size(); i++) {
            System.out.println("À l'indice " + i + " : " + exampleList.get(i));
        }

        // Prints the element at each index in the list using an iterator
        System.out.println("");
        int i = 0;
        for (Character chr: exampleList) {
            System.out.println("À l'indice " + i + " : " + chr);
            i++;
        }

        // Doubles each element in the list and prints the result
        ArrayList<String> doubledList = ArrayListDemo.doubleCharacters(exampleList);
        System.out.println("");
        System.out.println("Après doublement : " + doubledList);

        System.out.println("");

    }

    /**
     * Returns a list made of the same characters as a given one, but each one doubled
     * (into a String).
     * @param charList A list of Character's
     * @return A list of strings
     */
    public static ArrayList<String> doubleCharacters (ArrayList<Character> charList) {
        ArrayList<String> res = new ArrayList<> ();
        for (Character chr: charList) {
            res.add("" + chr + chr);
        }
        return res;
    }

}

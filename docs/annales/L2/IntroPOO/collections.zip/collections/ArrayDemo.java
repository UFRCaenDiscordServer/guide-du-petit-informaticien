package collections;

import java.util.Arrays;

/**
 * An executable class for demonstrating the use of arrays (esp., of class EquationSystem).
 */
public class ArrayDemo {

    /**
     * Runs the demo.
     * @param args ignored
     */
    public static void main (String [] args) {

        System.out.println("");

        // Creates a system of equations and prints it

        EquationSystem equationSystem = new EquationSystem (2, 2);
        System.out.println("Équations:");
        System.out.println(equationSystem);

        System.out.println("");
        System.out.println("Ajout de l'équation 2 x_1 - x_2 = -1...");
        float [] coefficients0 = {2, -1};
        equationSystem.setEquation(0, coefficients0, -1);
        System.out.println("");
        System.out.println("Équations:");
        System.out.println(equationSystem);

        System.out.println("Ajout de l'équation -3 x_1 - 1.5 x_2 = 10.5...");
        float [] coefficients1 = {-3, -1.5f};
        equationSystem.setEquation(1, coefficients1, 10.5f);
        System.out.println("");
        System.out.println("Equations:");
        System.out.println(equationSystem);

        // Decides and prints satisfaction for specific assignments

        float [] assignment1 = {-2, -3};
        boolean isSatisfied1 = equationSystem.isSatisfiedBy(assignment1);
        System.out.println("Satisfait par " + Arrays.toString(assignment1) + " ? " + isSatisfied1);

        float [] assignment2 = {2, -3};
        boolean isSatisfied2 = equationSystem.isSatisfiedBy(assignment2);
        System.out.println("Satisfait par " + Arrays.toString(assignment2) + " ? " + isSatisfied2);

        float [] assignment3 = {-4, 1};
        boolean isSatisfied3 = equationSystem.isSatisfiedBy(assignment3);
        System.out.println("Satisfait par " + Arrays.toString(assignment3) + " ? " + isSatisfied3);

        System.out.println("");

    }

}

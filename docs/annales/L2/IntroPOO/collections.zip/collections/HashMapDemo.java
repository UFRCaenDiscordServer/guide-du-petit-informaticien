package collections;

import java.util.HashMap;
import java.util.Map;

/**
 * An executable class for demonstrating the use of HashMap's.
 */
public class HashMapDemo {

    /**
     * Runs the demo.
     * @param args ignored
     */
    public static void main (String [] args) {

        Diploma l3 = new Diploma ("L3 informatique", "2017-2018");
        Diploma m1 = new Diploma ("M1 informatique", "2017-2018");
        Diploma m2 = new Diploma ("M2 informatique", "2017-2018");

        System.out.println("");

        // Creates a map from diplomas to internship durations (as descriptive strings) and prints it

        HashMap<Diploma, String> internshipDurations = new HashMap<> ();
        internshipDurations.put(l3, "10 semaines");
        internshipDurations.put(m1, "8 semaines, facultatif");
        internshipDurations.put(m2, "au moins 4 et au plus 6 moi");
        // Correcting the typo by replacing the value associated to M2
        internshipDurations.put(m2, "au moins 4 et au plus 6 mois");

        System.out.println("Stages : " + internshipDurations);

        // Retrieving info for given diplomas

        System.out.println("");
        System.out.println("Quelques informations :");
        System.out.println("");

        Diploma l2search = new Diploma ("L2 informatique", "2017-2018");
        Diploma l3search = new Diploma ("L3 informatique", "2017-2018");
        Diploma [] search = new Diploma [2];
        search[0] = l2search;
        search[1] = l3search;

        for (Diploma diploma: search) {
            System.out.print("Stage pour " + diploma + " : ");
            String info = internshipDurations.get(diploma);
            if (info == null) {
                System.out.println("aucune information.");
            } else {
                System.out.println(info);
            }
        }

        // Printing all the info

        System.out.println("");
        System.out.println("Toute l'information :");
        System.out.println("");

        for (Map.Entry<Diploma, String> e: internshipDurations.entrySet()) {
            System.out.println(e.getKey() + " : " + e.getValue());
        }
        
        System.out.println("");

    }

}

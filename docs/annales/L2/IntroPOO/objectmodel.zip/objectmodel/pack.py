class Sugar:

    def __init__(self, weight):
        self.weight = weight

    def getWeight(self):
        return self.weight

    
class Oil:

    def __init__(self, volume):
        self.volume = volume

    def getWeight(self):
        return 0.9 * self.volume

    pass


class Air:

    def __init__(self, volume):
        self.volume = volume

        
class Pack:

    def __init__(self):
        self.objects = []

    def add(self, obj):
        self.objects.append(obj)

    def getContainedWeight(self):
        return sum([obj.getWeight() for obj in self.objects])

    
def printWeight(pack):
    try:
        print("Poids du paquet:", pack.getContainedWeight())
    except AttributeError as e:
        print(e)


if __name__ == "__main__":

    print()

    print("Création d'un paquet vide...")
    aPack = Pack()

    print()

    print("Ajout d'1 kg de sucre...")
    sugar = Sugar(1)
    aPack.add(sugar)
    printWeight(aPack)

    print()

    print("Ajout de 2 L d'huile...")
    oil = Oil(2)
    aPack.add(oil)
    printWeight(aPack)

    print()

    print("Ajout de 3 L d'air...")
    air1 = Air(3)
    aPack.add(air1)
    printWeight(aPack)

    print()

    def getAirWeight (): return 0
    print("Ajout d'une méthode getWeight à l'instance d'Air...")
    air1.getWeight = getAirWeight
    printWeight(aPack)

    print()

    print("Ajout de 4 L d'air...")
    air2 = Air(4)
    aPack.add(air2)
    printWeight(aPack)

    print()

    print("Ajout d'une méthode getWeight à la classe Air...")
    Air.getWeight = lambda self: getAirWeight()
    printWeight(aPack)

    print()


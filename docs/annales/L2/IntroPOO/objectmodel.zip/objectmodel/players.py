class Player:

    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.__class__.__name__ + " " + self.name

    @classmethod
    def make_with_number(cls, i):
        name = "#" + str(i)
        return cls(name)


class Human(Player):

    pass


class Random(Player):

    pass


if __name__ == "__main__":

    players = []
    
    players.append(Human("Marie"))
    players.append(Human("Paul"))
    players.append(Human.make_with_number("3"))
    players.append(Human.make_with_number("4"))

    players.append(Random("R2D2"))
    players.append(Random("C3PO"))
    players.append(Random.make_with_number("3"))
    players.append(Random.make_with_number("4"))

    for player in players:
        print(player)

        

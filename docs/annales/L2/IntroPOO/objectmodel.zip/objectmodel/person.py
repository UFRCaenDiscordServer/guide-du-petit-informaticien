class Person:

    def __init__(self, firstName, lastName):
        self.firstName = firstName
        self.lastName = lastName
        
    def hello(self):
        return "Bonjour, je suis " + self.firstName + " " + self.lastName


class Contact(Person):

    def __init__(self, firstName, lastName, address):
        Person.__init__(self, firstName, lastName)
        self.address = address

    def hello(self):
        return Person.hello(self) + ", pour me contacter : " + self.address


if __name__ == "__main__":

    aPerson = Person("Jean", "Martin")
    aContact = Contact("Jane", "Doe", "jane.doe@mail.com")
    print(aPerson.hello())
    print(aContact.hello())


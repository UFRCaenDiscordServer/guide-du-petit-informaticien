class AbstractGame:

    def __init__(self, name1, name2):
        self.name1 = name1
        self.name2 = name2

    def players_to_string(self):
        return "Partie de " + self.game + " entre " + self.name1 + " et " + self.name2
        
    @classmethod
    def several_moves_to_string(cls, moves):
        res = ""
        i = 1
        for move in moves:
            res = res + "\n" + str(i) + ") " + cls.move_to_string(move)
            i = i+1
        return res


class Nim(AbstractGame):

    def __init__(self, initialNb, maxNb, name1, name2):
        AbstractGame.__init__(self, name1, name2)
        self.initialNb = initialNb
        self.maxNb = maxNb
        self.game = "Nim (init. : " + str(initialNb) + ", max. : " + str(maxNb) + ")"
    
    @staticmethod
    def move_to_string(move):
        return str(move)


class TicTacToe(AbstractGame):

    game = "Morpions"
    
    @staticmethod
    def move_to_string(move):
        row, column = divmod(move, 3)
        return "(" + str(row + 1) + "," + str(column+1) + ")"


if __name__ == "__main__":

    print()

    nim1 = Nim(11, 3, "Marie", "Jean")
    nim2 = Nim(9, 3, "Mary", "John")
    tic_tac_toe = TicTacToe("Maria", "Giovanni")
    for game in [nim1, nim2, tic_tac_toe]:
        print(game.players_to_string())

    print()
        
    moves = [1,2,3]
    print("À Nim, affichage des coups", moves)
    print(Nim.several_moves_to_string(moves))

    print()
        
    moves = [1,4,8]
    print("Aux Morpions, affichage des coups", moves)
    print(TicTacToe.several_moves_to_string(moves))

    print()


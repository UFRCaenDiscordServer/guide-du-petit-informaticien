package encoding;

/**
 * An encoder for strings, which replaces all characters from the Lateen alphabet by their ASCII code.
 */
public class ASCIICodeEncoder extends Encoder {

    /**
     * Builds a new instance.
     */
    public ASCIICodeEncoder() {
        super();
    }
    
    @Override
    public String encodeCharacter(char c) {
        if ( ( 'a' <= c && c <= 'z' ) || ( 'A' <= c && c <= 'Z' ) ) {
            return "" + (int)c;
        }
        return "" + c;
    }
    
}

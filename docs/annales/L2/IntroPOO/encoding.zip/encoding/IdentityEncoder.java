package encoding;

/**
 * An encoder for strings, which leaves the string unchanged.
 */
public class IdentityEncoder extends Encoder {

    /**
     * Builds a new instance.
     */
    public IdentityEncoder() {
        super();
    }
    
    @Override
    public String encodeCharacter(char c) {
        return "" + c;
    }
    
}

package encoding;

/**
 * An encoder for strings, which applies Cesar's encoding for a given key to all characters from the Lateen alphabet.
 */
public class CesarEncoder extends Encoder {
    
    /** The offset to apply to characters. */
    protected int offset;
    
    /**
     * Builds a new instance.
     * @param offset the offset to apply to characters
     */
    public CesarEncoder(int offset) {
        super();
        this.offset = offset;
    }

    @Override
    public String encodeCharacter(char c) {
        if ( 'a' <= c && c <= 'z' ) {
            int index = c - 'a';
            int newIndex = (index + this.offset) % 26;
            return "" + (char) ('a' + newIndex);
        } else if ( 'A' <= c && c <= 'Z' ) {
            int index = c - 'A';
            int newIndex = (index + this.offset) % 26;
            return "" + (char) ('A' + newIndex);
        } else {
            return "" + c;
        }
    }
    
}

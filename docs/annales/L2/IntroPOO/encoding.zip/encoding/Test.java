package encoding;

import volumes.Cube;
import volumes.Cylinder;
import volumes.Figure;
import volumes.Parallelepiped;
import volumes.Prism;

/**
 * An executable class for testing the classes and methods of this package.
 */
public class Test {

    /**
     * Runs a series of tests, printing "OK" or "KO" for each one.
     * @param args ignored
     */
    public static void main(String[] args) {

        String str = "Une chaîne pour l'exemple.";
        String expected;
        Encoder encoder;

        // Identity encoder
        System.out.println("Testing identity encoder...");
        encoder = new IdentityEncoder();
        expected = str;
        Test.check(str, encoder, expected);

        // Trivial encoder
        System.out.println("Testing trivial encoder...");
        encoder = new TrivialEncoder('a');
        expected = "aaa aaaîaa aaaa a'aaaaaaa.";
        Test.check(str, encoder, expected);

        // Cesar encoder
        System.out.println("Testing Cesar encoder...");
        encoder = new CesarEncoder(3);
        expected = "Xqh fkdîqh srxu o'hahpsoh.";
        Test.check(str, encoder, expected);

        // Cesar encoder
        System.out.println("Testing upper case encoder...");
        encoder = new UpperCaseEncoder();
        expected = "UNE CHAîNE POUR L'EXEMPLE.";
        Test.check(str, encoder, expected);

        // ASCII encoder
        System.out.println("Testing ASCII encoder...");
        encoder = new ASCIICodeEncoder();
        expected = "Une chaîne pour l'exemple.";
        expected = "85110101 9910497î110101 112111117114 108'101120101109112108101.";
        Test.check(str, encoder, expected);

    }

    /**
     * Checks whether the encoding of a given string computed by a given encoder
     * is the expected one. Prints "OK" or "KO" (with information) depending on
     * whether the test passes or fails.
     * @param str A string
     * @param encoder An encoder
     * @param expected The expected encoding of the given string by the given
     *            encoder
     */
    public static void check(String str, Encoder encoder, String expected) {
        String encoded = encoder.encode(str);
        if (encoded.equals(expected)) {
            System.out.println("OK");
        } else {
            System.out.println("KO (found " + encoded + ", expected "
                    + expected);
        }
    }

}

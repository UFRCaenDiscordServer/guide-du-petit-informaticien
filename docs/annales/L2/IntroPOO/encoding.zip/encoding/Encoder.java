package encoding;

/**
 * An abstract class for encoders (of strings into strings).
 */
public abstract class Encoder {

    /**
     * Builds a new instance.
     */
    public Encoder () {
    }
    
    /**
     * Returns the encoding of a given character.
     * @param c A character
     * @return The encoding of the given character
     */
    public abstract String encodeCharacter (char c);
    
    /**
     * Returns the encoding of a given string.
     * @param str A string
     * @return The encoding of the given string
     */
    public String encode (String str) {
        StringBuilder builder = new StringBuilder("");
        for (int i = 0; i < str.length(); i++) {
            builder.append(this.encodeCharacter(str.charAt(i)));
        }
        return builder.toString();      
    }
    
}

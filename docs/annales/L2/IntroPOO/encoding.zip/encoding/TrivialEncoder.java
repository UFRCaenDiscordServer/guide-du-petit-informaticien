package encoding;

/**
 * An encoder for strings, which replaces all characters from the Lateen alphabet by the same character.
 */
public class TrivialEncoder extends Encoder {

    /** The character by which to replace all characters, as a string. */
    protected String output;
    
    /**
     * Builds a new instance.
     * @param outputCharacter the character by which to replace all characters
     */
    public TrivialEncoder(char outputCharacter) {
        super();
        this.output = "" + outputCharacter;
    }
    
    @Override
    public String encodeCharacter(char c) {
        if ( ( 'a' <= c && c <= 'z' ) || ( 'A' <= c && c <= 'Z' ) ) {
            return this.output;
        } else {
            return "" + c;
        }
    }
    
}

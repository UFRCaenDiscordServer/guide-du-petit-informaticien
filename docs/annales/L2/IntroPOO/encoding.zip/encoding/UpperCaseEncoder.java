package encoding;

/**
 * An encoder for strings, which replaces all characters from the Lateen alphabet by the cooresponding upper case character.
 */
public class UpperCaseEncoder extends Encoder {
    
    /**
     * Builds a new instance.
     */
    public UpperCaseEncoder() {
        super();
    }
    
    @Override
    public String encodeCharacter(char c) {
        if ( 'a' <= c && c <= 'z' ) {
            return "" + (char) (c + 'A' - 'a' );
        }
        return "" + c;
    }

}

package exceptions;

import java.io.IOException;

/**
 * A class for demonstrating the use of exceptions.
 */
public class Demo {

	private static char[] operators = { '+', '-', '*', '/' };

	/**
	 * Evaluates a binary operation over nonnegative integers given as an argument,
	 * and prints the result. Prints an error message to standard error if the
	 * expression is not well-formed.
	 * 
	 * @param args args[0] should be a binary expression over integers, as specified
	 *             for method {@link #evaluate(String)
	 */
	public static void main(String[] args) {

		if (args.length != 1) {
			System.err.println("Usage: " + Demo.class.getCanonicalName() + " expression");
			System.err.println(
					"with expression of the form \"a+b\", \"a-b\", \"a/b\", or \"a/b\" (without any whitespace).");
			System.exit(1);
		}
		String operation = args[0];
		float res = 0;
		try {
			res = Demo.evaluate(operation);
		} catch (IOException e) {
			System.err.println("An I/O error occurred while evaluating the expression: " + e.getMessage());
			System.exit(2);
		} catch (Exception e) {
			System.err.println("An unexpected error occurred while evaluating the expression: " + e.toString());
			System.exit(2);
		}
		System.out.println("Operation: " + operation);
		System.out.println("Result: " + res);

	}

	/**
	 * Evaluates an arithmetic expression given as a string and returns its value.
	 * 
	 * @param expression A binary operation over nonnegative integers, written as a
	 *                   string of the form "a+b", "a-b", "a*b", or "a/b", without
	 *                   any whitespace and where a, b are nonnegative integers.
	 * @return the result of the encoded operation
	 * @throws IOException if the expression cannot be parsed
	 */
	public static float evaluate(String expression) throws IOException {
		for (char op : Demo.operators) {
			if (expression.indexOf(op) != -1) {

				// Technicality: escaping special characters +, * (for split)
				String pattern = (op == '+' ? "\\+" : op == '*' ? "\\*" : "" + op);
				String[] operands = expression.split(pattern);

				if (operands.length != 2) {
					throw new IOException("Ill-formed expression, should have two operands: " + expression);
				}
				int leftOperand = Integer.parseInt(operands[0]);
				int rightOperand = Integer.parseInt(operands[1]);
				if (leftOperand < 0 || rightOperand < 0) {
					throw new IOException("Ill-formed expression, at least one operand is negative: " + leftOperand
							+ ", " + rightOperand);
				}

				return Demo.evaluate(leftOperand, op, rightOperand);
			}
		}
		throw new IOException("Ill-formed expression, does not contain any valid operaor: " + expression);
	}

	/**
	 * Evaluates a binary operation over floats
	 * 
	 * @param a  The left operand
	 * @param op An operator among '+', '-', '*', '/'
	 * @param b  The right operand
	 * @return The result of the operation
	 * @throws IllegalArgumentException if the operator is not among those allowed
	 */
	public static float evaluate(int a, char op, int b) throws IllegalArgumentException {
		switch (op) {
		case '+':
			return a + b;
		case '-':
			return a - b;
		case '*':
			return a * b;
		case '/':
			return a / b;
		default:
			throw new IllegalArgumentException("Unknown operator: " + op);
		}
	}

}

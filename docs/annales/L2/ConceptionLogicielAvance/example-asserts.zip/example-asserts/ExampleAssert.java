import java.util.*;

class Bidule implements Comparable
{
	Integer number;
	Integer version;
	
	public Bidule(int version, int number)
	{
		this.number = new Integer(number);
		this.version = new Integer(version);
		System.out.print("Je suis un bidule " + this + " version " + this.version + "." + this.number + "\n");
	}
	
	public int compareTo(Object o)
	{
		Bidule i = (Bidule) o;
		if (this.version.equals(i.version))
		{
			return this.number.compareTo(i.number);
		}
		return this.version.compareTo(i.version);
	}
}

public class ExampleAssert
{
	public static void main(String[] args) 
	{
		// Fonctional invariant
		int value = new Integer(args[0]);
		int bound = new Integer(args[1]);
		assert value > 0 && bound > 0 : "The parameters must be positive integers";
		
		Random generator = new Random();
		ArrayList<Bidule> factory = new ArrayList<Bidule>();
		for (int i = 0; i < 10; i++)
		{
			// Logical invariant
			int a = generator.nextInt(value);
			int b = generator.nextInt(value);
			assert a >=0 && b >=0 : "A negative random int has been generated";

			factory.add(new Bidule(generator.nextInt(value), generator.nextInt(value)));
		}

		System.out.println();

		Collections.sort(factory);
		Iterator<Bidule> i = factory.iterator();
		while (i.hasNext())
		{
			Bidule b = i.next();
			if (b.number + b.version > bound) {
				System.out.println(b.version + " " + b.number + " : " + b);
				System.exit(0);
			}
		}
		
		// Flux control invariant
		assert false : "A lower bound has not be found";
	}
}

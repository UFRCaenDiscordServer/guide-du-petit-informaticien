import paquet.*;
import paquet.souspaquet.*;

public class ExamplePaquet {
	public static void main (String[] args){
		System.out.println("Je me lance");
		Bidule a = new Bidule();
		Truc b = new Truc();
	}
}

package paquet.souspaquet;

public class Machin {
	public Machin (){
		System.out.println("Je suis le machin");
	}
}

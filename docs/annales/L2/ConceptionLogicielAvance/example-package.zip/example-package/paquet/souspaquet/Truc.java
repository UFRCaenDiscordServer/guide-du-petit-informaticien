package paquet.souspaquet;
import paquet.Bidule;

public class Truc {
	public Truc (){
		System.out.println("Je suis le truc");
		Bidule b = new Bidule();
	}
}

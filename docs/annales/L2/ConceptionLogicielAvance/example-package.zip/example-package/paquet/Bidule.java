package paquet;
import paquet.souspaquet.Machin;

public class Bidule {
	public Bidule (){
		System.out.println("Je suis le bidule");
		Machin m = new Machin();
	}
}

public class ExempleAnt {
	public static void main(String[] args) {
		System.out.println("I've been executed");
	}
}
